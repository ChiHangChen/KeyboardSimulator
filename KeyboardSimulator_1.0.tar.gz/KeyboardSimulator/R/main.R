

# Keyboard ---------------------------------------------------------------


keyboard_value<-read.csv("./data/keyboardvalue.csv")

keybd.press_and_release <- function(button) {
  if(!is.character(button))
    stop("Argument must be character")
  button_str<-sapply(setdiff(strsplit(button,"\\+")[[1]],"\\+"),tolower)
  button_check<-!button_str%in%keyboard_value$button
  if( any(button_check) )
    stop(paste0("No such button ", paste(button_str[button_check],collapse = ' and ')))
  button_value<-sapply(button_str,function(i) keyboard_value$value[keyboard_value$button==i])
  press_and_release_c(as.vector(button_value))
}

keybd.press_and_hold <- function(button,duration) {
  if(!is.character(button))
    stop("Argument must be character")
  button_str<-sapply(setdiff(strsplit(button,"\\+")[[1]],"\\+"),tolower)
  button_check<-!button_str%in%keyboard_value$button
  if( any(button_check) )
    stop(paste0("No such button ", paste(button_str[button_check],collapse = ' and ')))
  button_value<-sapply(button_str,function(i) keyboard_value$value[keyboard_value$button==i])
  press_c(as.vector(button_value))
}


keybd.release <- function(button) {
  if(!is.character(button))
    stop("Argument must be character")
  button_str<-sapply(setdiff(strsplit(button,"\\+")[[1]],"\\+"),tolower)
  button_check<-!button_str%in%keyboard_value$button
  if( any(button_check) )
    stop(paste0("No such button ", paste(button_str[button_check],collapse = ' and ')))
  button_value<-sapply(button_str,function(i) keyboard_value$value[keyboard_value$button==i])
  release_c(as.vector(button_value))
}



# Mouse -------------------------------------------------------------------

mouse.left_click<-function(){
  mouse_left_click()
}

mouse.right_click<-function(){
  mouse_right_click()
}
